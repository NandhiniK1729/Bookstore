package com.capgemini.book_store.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.book_store.bean.Customer;

public interface CustomerRepo extends JpaRepository<Customer, String> {
public Customer findByemailId(String email);
}
