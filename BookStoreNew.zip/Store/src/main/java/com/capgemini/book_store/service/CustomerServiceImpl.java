package com.capgemini.book_store.service;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.dao.CustomerRepo;


@Service("customerService")

public class CustomerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepo repo;

	@Override
	public Customer Create(String email, String cname, String password, String c_Password, String mobile,
			String address, String city, String zipcode, String country) {
		Customer c = new Customer();
		c.setEmailId(email);
		c.setCustomerName(cname);
		c.setPassword(password);
		c.setConfirmPassword(c_Password);
		c.setMobileNumber(mobile);
		c.setAddress(address);
		c.setCity(city);
		c.setZipcode(zipcode);
		c.setCountry(country);
		Customer c1=repo.save(c);
		System.out.println(c1);
		return c1;

	}

	@Override
	public Customer validate(String email, String password) {
		System.out.println(email);
		Customer c = repo.findByemailId(email);
		// Check for mailId and Password :
		System.out.println(c);
		if(c!=null)
		{
		if (c.getEmailId().equals(email) && c.getPassword().equals(password)) {
			return c;
		} else
			return null;
		}
		return null;
	}

	@Override
	public Customer update(String cname, String password, String mobile, String confirmPassword, String address,
			String city, String zipcode, String country) {
		Customer c = new Customer();
		c.setCustomerName(cname);
		c.setPassword(password);
		c.setConfirmPassword(confirmPassword);
		c.setMobileNumber(mobile);
		c.setAddress(address);
		c.setCity(city);
		c.setZipcode(zipcode);
		c.setCountry(country);
		repo.save(c);
		return c;
	}

}
