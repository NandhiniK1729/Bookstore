package com.capgemini.book_store.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.bean.Order;
import com.capgemini.book_store.service.CustomerService;
import com.capgemini.book_store.service.OrderService;

@RestController

public class CustomerController {



		@Autowired
		CustomerService service;
		@Autowired
		OrderService orderService;

		@GetMapping("/Create/{emailId}/{customerName}/{password}/{confirmPassword}/{mobileNumber}/{address}/{city}/{zipcode}/{country}")
		public String Create(@PathVariable("emailId") String emailId, @PathVariable("customerName") String customerName,
				@PathVariable("password") String password, @PathVariable("confirmPassword") String confirmPassword,
				@PathVariable("mobileNumber") String mobileNumber, @PathVariable("address") String address,
				@PathVariable("city") String city, @PathVariable("zipcode") String zipcode,
				@PathVariable("country") String country) {
			/*
			 * //to check on the conditions of inputs!!!!
			 * 
			 */

			Customer c1 = service.Create(emailId, customerName, password, confirmPassword, mobileNumber, address, city,
					zipcode, country);
			if (c1 != null) {
				String register = "Customer Details:" + c1;
				return register;
			} else {
				return "Register it again...";
			}

		}

		@RequestMapping("/validate/{emailId}/{password}")
		public String validate(@PathVariable("emailId") String emailId, @PathVariable("password") String password) {
			Customer c1 = service.validate(emailId, password);
			if (c1 != null) {
				return "successfull Login...." + c1.getCustomerName();
			}

			return "Invalid Credentials......";

		}

		@GetMapping("/editProfile/{customerName}/{mobileNumber}/{address}/{city}/{zipcode}/{country}/{password}/{confirmPassword}")
		public String update(@PathVariable("customerName") String customerName,
				@PathVariable("mobileNumber") String mobileNumber, @PathVariable("address") String address,
				@PathVariable("city") String city, @PathVariable("zipcode") String zipcode,
				@PathVariable("country") String country, @PathVariable("password") String password,
				@PathVariable("confirmPassword") String confirmPassword) {
			Customer c1 = service.update(customerName, password, mobileNumber, confirmPassword, address, city, zipcode,
					country);
			if (c1 != null)
				return "Succesfully Updated...";
			else
				return "Failed....";

		}
		
		@GetMapping("/viewOrder/{customerName}")
		public List<Order> viewOrder(@PathVariable("customerName") String customerName)
		{
			List<Order> order=orderService.vieworders(customerName);
			return order;
		}

	}

	


