package com.capgemini.book_store.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.book_store.bean.Book;
import com.capgemini.book_store.bean.Customer;
import com.capgemini.book_store.bean.Review;
import com.capgemini.book_store.service.ReviewService;




@RestController
@RequestMapping("/rest")
public class ReviewController 
{
	@Autowired
	ReviewService reviewService;
	@RequestMapping("/search/{bookName}")
	public String search( @PathVariable("bookName") String bookName)
	{
		System.out.println(bookName);
		Book b=reviewService.search(bookName);
		if(b!=null)
		{
			String s="Customer details are "+b;
			return s;
		}
		else
			return "Book not found!!!";
	}
	
	@RequestMapping("/createReview/{cname}/{bookName}/{rating}/{headline}/{comment}")
	public String create(@PathVariable("cname") String cname,@PathVariable("bookName") String bookName,@PathVariable("rating") int rating,@PathVariable("headline") String headline,@PathVariable("comment") String comment)
	{
		/*Customer customer=reviewService.validate(cname);
		if(customer!=null)
		{
		Review review=reviewService.CreateReview(cname, bookName, rating, headline, comment);
		reviewService.average(bookName, rating);
		return "Thank you for giving the review";
		}
		else
		{
			return "Review can be given only once";
		}*/
		Review review=reviewService.CreateReview(cname, bookName, rating, headline, comment);
		reviewService.average(bookName, rating);
		return "Thank you for giving the review";
	}
	
	@RequestMapping("/favbook")
  public List<Book> favBook()
{
	List<Book> blist=reviewService.findByRating();
	return blist;
}
	@RequestMapping("/bestbook")
  public List<Book> bestBook()
  {
	  List<Book> blist=reviewService.findByOrder();
	  return blist;
	  
  }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
