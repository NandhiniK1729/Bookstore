package com.capgemini.book_store.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.book_store.bean.Book;

public interface IBookDAO extends JpaRepository<Book, String>{
	public Book findBytitle(String bookName);
}
