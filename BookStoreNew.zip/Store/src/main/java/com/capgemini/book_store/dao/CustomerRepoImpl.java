package com.capgemini.book_store.dao;



public class CustomerRepoImpl  {
//	@PersistenceContext
//	EntityManager entityManager;
//
//	@Override
//	public boolean save(Customer c) {
//		entityManager.persist(c);
//		return true;
//	}

}
