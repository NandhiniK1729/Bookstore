package com.capgemini.book_store.controller;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.book_store.bean.Book;
import com.capgemini.book_store.bean.Order;
import com.capgemini.book_store.service.OrderService;
@RestController
@RequestMapping("/rest")
public class OrderController
{
	List<Book> blist=new LinkedList<Book>();
	Order o;
	@Autowired
	OrderService service;
	@RequestMapping("/update/{quantity}/{bookname}")
	public String update(@PathVariable("quantity")int quantity,@PathVariable("bookname")String bookname)
	{
		Order o=service.update(quantity,bookname);
		return "updated quantity is "+ o.getQuantity();
		
	}
	@RequestMapping("/createOrder/{quantity}/{bookname}/{recipient}")
	public String placeorder(@PathVariable("quantity")int quantity,@PathVariable("bookname")String bookname,@PathVariable("recipient")String recipient)	
   {
		Book b=service.findByBookName(bookname);
		double amount=b.getPrice();
		int bookId=b.getBookId();
		o=service.createOrder(quantity, amount, "COD", bookId, recipient,bookname);
	return "Your order has been placed successfuly"+ o;
	
    }
	@RequestMapping("/display")
	public String DisplayAmount()
	{
		double o1=service.invoice(o);
		return "The total amount for your order is "+ o1;
		
	}
	@RequestMapping("/AddToCart/{bookname}")
	public List<Book> AddToCart(@PathVariable("bookname")String bookname)
	{
		Book b=service.findByBookName(bookname);
	    blist.add(b);
	    return blist;
		
	}
	@RequestMapping("/delete/{bookname}")
	public String delete(@PathVariable("bookname")String bookname)
	{
		Book b=service.findByBookName(bookname);
	//	int id=b.getBookId();
		blist.remove(b);
		return "Successfully deleted";
	}
}

